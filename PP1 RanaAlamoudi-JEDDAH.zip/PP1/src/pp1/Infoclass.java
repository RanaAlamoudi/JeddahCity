/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pp1;
import java.io.Serializable;


/**
 
 * @author Rana_Alamoudi
 * Jana Falata
 */
public class Infoclass implements Serializable{
    
    private String name;
    private String phone;
    private String checkindate;
    private String checkoutdate;
   

    public Infoclass(String name, String phone, String checkindate, String checkoutdate) {
        this.name = name;
        this.phone = phone;
        this.checkindate = checkindate;
        this.checkoutdate = checkoutdate;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setCheckindate(String checkindate) {
        this.checkindate = checkindate;
    }

    public void setCheckoutdate(String checkoutdate) {
        this.checkoutdate = checkoutdate;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getCheckindate() {
        return checkindate;
    }

    public String getCheckoutdate() {
        return checkoutdate;
    }
}
