/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pp1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Rana_Alamoudi
 * Jana Falata
 */
public class PP4Controller implements Initializable {

    @FXML
    private AnchorPane window4;
    @FXML
    private ImageView Gimage;
    @FXML
    private ImageView Aimage;
    @FXML
    private ImageView Pimage;
    @FXML
    private ImageView Cimage;
    @FXML
    private Label galleriaName;
    @FXML
    private Label AscottName;
    @FXML
    private Label parkName;
    @FXML
    private Label crowneName;
    @FXML
    private Label galleriaLabel1;
    @FXML
    private Label galleriaLabel2;
    @FXML
    private Button Gbutton;
    @FXML
    private Label AscottLabel1;
    @FXML
    private Label AscottLabel2;
    @FXML
    private Button Abutton;
    @FXML
    private Button Pbutton;
    @FXML
    private Button Cbutton;
    @FXML
    private Label parkLabel1;
    @FXML
    private Label parkLabel2;
    @FXML
    private Label crowneLabel1;
    @FXML
    private Label crowneLabel2;
    @FXML
    private ImageView rating2;
    @FXML
    private ImageView star1;
    @FXML
    private ImageView star2;
    @FXML
    private ImageView star3;
    @FXML
    private ImageView rating1;
    @FXML
    private ImageView rating3;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

   // handles the event that is generated when the user selects book now button from one of the hotels 
    
    @FXML
    private void GbuttonAction(ActionEvent event) { 
         try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("PPP5.fxml"));
            Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
        
        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        }
    }

    @FXML
    private void AbuttonAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("PPP5.fxml"));
            Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
        
        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        }
    }

    @FXML
    private void PbuttonAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("PPP5.fxml"));
            Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
        
        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        }
    }

    @FXML
    private void CbuttonAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("PPP5.fxml"));
            Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
        
        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        }
    }
    
}
