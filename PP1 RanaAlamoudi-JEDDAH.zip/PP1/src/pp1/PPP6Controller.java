/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pp1;

import java.awt.Font;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javax.swing.JOptionPane;


/**
 * FXML Controller class
 *
 * @author Rana_Alamoudi
 * Jana Falata
 */
public class PPP6Controller implements Initializable {

    @FXML
    private AnchorPane W6;
    @FXML
    private Label thankyouLabel;
    @FXML
    private Label bookingLabel;
    @FXML
    private Label codeLabel;
    @FXML
    private ImageView codeimage;
    @FXML
    private Button homepageButon;
    @FXML
    private Label NAME;
    @FXML
    private Label PHONEE;
    @FXML
    private Label INNDATE;
    @FXML
    private Label OUTDATEE;
    @FXML
    private Label LABELPHONE;
    @FXML
    private Label LABELNAME;
    @FXML
    private Label INDATEELABEL;
    @FXML
    private Label LABELOUTDATE;
        
    private Infoclass s;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        readFile();
        // TODO
    }    

    @FXML
    private void HomePageAction(ActionEvent event) { // move to window 3
        try {                  
            FXMLLoader loader = new FXMLLoader(getClass().getResource("PP3.fxml"));
            Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
        
        } 
        catch (IOException io) {
            System.out.println("FXML Loading Error");
        }
        catch (Exception e) {
            System.out.println("Invalid input");
        }
    }
         
        public void readFile() {
        try {
            FileInputStream file = new FileInputStream("Reservation.txt");
            ObjectInputStream reader = new ObjectInputStream(file);
            while (true) {
                try { 
                    s = (Infoclass)reader.readObject();
                        printTicket();
                    
                } catch (Exception ex) {
                    System.out.println("end of reader file ");
                    break;
                }
        }
        } catch (Exception ex) {
            System.out.println("Error in reading file");
        }

    }
        private void printTicket(){
           LABELNAME.setText(s.getName());
           LABELPHONE.setText(s.getPhone());
           INDATEELABEL.setText(s.getCheckindate());
           LABELOUTDATE.setText(s.getCheckoutdate());
            
        }
    
  
     }
  
