/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pp1;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Callback;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Rana_Alamoudi 
 * Jana Falata
 */
public class PPP5Controller implements Initializable {

    @FXML
    private AnchorPane window5;
    @FXML
    private Label checkINdate;
    @FXML
    private Label checkOUT;
    @FXML
    private Label completeLabel;
    @FXML
    private Label adultsLabel;
    @FXML
    private Label childrenLabel;
    @FXML
    private Label shuttleLabel;
    @FXML
    private Label guestLabel;
    @FXML
    private DatePicker INDate;
    @FXML
    private DatePicker OUTDate;
    @FXML
    private RadioButton radioyes;
    @FXML
    private ToggleGroup radiobutton2;
    @FXML
    private RadioButton radiono;
    @FXML
    private TextField adultText;
    @FXML
    private TextField childrenText;
    @FXML
    private Label paymentLabel;
    @FXML
    private Label cardnoLabel;
    @FXML
    private TextField cardnoText;
    @FXML
    private Label cvvLabel;
    @FXML
    private Label expLabel;
    @FXML
    private TextField cvvText;
    @FXML
    private TextField expText;
    @FXML
    private TextField nameoncardText;
    @FXML
    private Label nameoncardLabel;
    @FXML
    private Label onlinepayLabel;
    @FXML
    private Label roomLabel;
    @FXML
    private Label includeLabel;
    @FXML
    private Label totalLabel;
    @FXML
    private CheckBox ViewExtra;
    @FXML
    private Label name2Label;
    @FXML
    private Label phone2Label;
    @FXML
    private TextField name2Text;
    @FXML
    private TextField phone2Text;
    @FXML
    private Button confirmButton;
    @FXML
    private ImageView image4;
     @FXML
    private Label TotalVat;
    @FXML
    private RadioButton KingRoom;
    @FXML
    private ToggleGroup RoomType;
    @FXML
    private RadioButton QueenRoom;
    @FXML
    private RadioButton RoyalRoom;
    @FXML
    private RadioButton TwinRoom;
    @FXML
    private RadioButton SingleRoom;
    @FXML
    private ComboBox<String> TimeComboBox;
    
    private Infoclass s;
        
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) { 
        final Callback<DatePicker, DateCell> dayCellFactory = (DatePicker) -> new DateCell() {

            @Override
            public void updateItem(LocalDate item, boolean empty) {
                super.updateItem(item, empty);
                if (item.isBefore(LocalDate.now())) {
                    setDisable(true);
                    setStyle("-fx-background-color: #ffc0cb;");
                }
            }
        };
        INDate.setDayCellFactory(dayCellFactory);
        OUTDate.setDayCellFactory(dayCellFactory);
                
        
/// Create list to display in combo box
        TimeComboBox.getItems().addAll(
                "1:00 AM",
                "2:00 AM",
                "3:00 AM",
                "4:00 AM",
                "5:00 AM",
                "6:00 AM",
                "7:00 AM",
                "8:00 AM",
                "9:00 AM",
                "10:00 AM",
                "11:00 AM",
                "12:00 AM",
                "1:00 PM",
                "2:00 PM",
                "3:00 PM",
                "4:00 PM",
                "5:00 PM",
                "6:00 PM",
                "7:00 PM",
                "8:00 PM",
                "9:00 PM",
                "10:00 PM",
                "11:00 PM",
                "12:00 PM"                 
        );
        // TODO
        
        
    }
    
    @FXML
    void BackAction(ActionEvent event) {
        // method that handles the event that is generated when the user selects back button
          try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("PP4.fxml"));
            Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
                   }

          catch (IOException io) {
            System.out.println("FXML Loading Error");
        }
    }
    

    @FXML  // method that handles the event that is generated when the user selects confirm button
    private void confirmAction(ActionEvent event) throws Exception { 
        inputValidation2();  //calling the mthod 
        s=new Infoclass(name2Text.getText(),phone2Text.getText(),INDate.getValue().toString(),OUTDate.getValue().toString());
        writeToFile(s);
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("PPP6.fxml"));
            Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
            
        } 
        catch (IOException io) {
            System.out.println("FXML Loading Error");
        }
    }
    
     public void SetUserInfo(String Name ,String Phone ,String Checkin , String Checkout){    
        s=new Infoclass(Name,Phone,Checkin,Checkout); 
     }
    
    @FXML
    void totalAction(ActionEvent event) { 
        //the reason from this method is to calculate the user choise from the radio and check box and print the total in label 
      
         if (KingRoom.isSelected()){
                TotalVat.setText("1600 SAR");
           }
         
          if (KingRoom.isSelected() && ViewExtra.isSelected()){ 
                TotalVat.setText("2000 SAR");
           }
          
           if (QueenRoom.isSelected()) {
                 TotalVat.setText("1500 SAR");
           }
           
           if (QueenRoom.isSelected()&& ViewExtra.isSelected()) {
                 TotalVat.setText("1900 SAR");
           }

           if (RoyalRoom.isSelected()) {
                TotalVat.setText("2000 SAR");
           }
           
           if (RoyalRoom.isSelected()&& ViewExtra.isSelected()) {
                TotalVat.setText("2400 SAR");
           }

           if (TwinRoom.isSelected()) {
                TotalVat.setText("900 SAR");
           }
           
          if (TwinRoom.isSelected()&& ViewExtra.isSelected()) {
                TotalVat.setText("1300 SAR");
           }
          
           if (SingleRoom.isSelected()) {
                TotalVat.setText("750 SAR");
           }
        
            if (SingleRoom.isSelected()&& ViewExtra.isSelected()) {
                TotalVat.setText("1,150 SAR");
           }
            
    }

    private void inputValidation2() throws Exception {
        // the reason from this method to check the condition i wrote if it dose not meet the condition then a messege will appear
        
        if (!validatename()) {
            JOptionPane.showMessageDialog(null, "Invalid Name !", "Message:", JOptionPane.ERROR_MESSAGE);
            throw new Exception();
        }
        if (!validatemobile()) {
            JOptionPane.showMessageDialog(null, "Invalid Mobile number !", "Message:", JOptionPane.ERROR_MESSAGE);
            throw new Exception();
        }    
        //if the user forgot to choose a time
        if(TimeComboBox.getValue() == null || TimeComboBox.getValue().equals("")){
         JOptionPane.showMessageDialog(null, "Choose Your Arrival Time Please !", "Message:", JOptionPane.ERROR_MESSAGE);
            throw new Exception();    
        }
        //if the user forgot to choose the date
          if (INDate.getValue() == null || INDate.getValue().equals("")){
          JOptionPane.showMessageDialog(null, "Choose check-In date Please !", "Message:", JOptionPane.ERROR_MESSAGE);
            throw new Exception(); 
         } 
              //if the user forgot to choose the date   
      if (OUTDate.getValue() == null || OUTDate.getValue().equals("")){
          JOptionPane.showMessageDialog(null, "Choose check-Out date Please !", "Message:", JOptionPane.ERROR_MESSAGE);
            throw new Exception();          
         } 
       //if the user forgot to choose the room 
      if (!KingRoom.isSelected() && !QueenRoom.isSelected() && !RoyalRoom.isSelected() && !TwinRoom.isSelected() && !SingleRoom.isSelected())
        {
            JOptionPane.showMessageDialog(null, "Please choose the Room Type !", "Message:", JOptionPane.ERROR_MESSAGE);
            throw new Exception();
        }
       //if the user forgot to choose the gender
        if (!radiono.isSelected() && !radioyes.isSelected()) {
            JOptionPane.showMessageDialog(null, "Please choose YES or NO for Airport Shuttle", "Message:", JOptionPane.ERROR_MESSAGE);
            throw new Exception();
        }
 
        if(!Adults()){
          JOptionPane.showMessageDialog(null, "Invalid Adults number !", "Message:", JOptionPane.ERROR_MESSAGE);
            throw new Exception();  
        }
        
        if(!children()){
          JOptionPane.showMessageDialog(null, "Invalid Children number !", "Message:", JOptionPane.ERROR_MESSAGE);
            throw new Exception();  
        }
        
      if(!cardNO()){
         JOptionPane.showMessageDialog(null, "Invalid Card number !", "Message:", JOptionPane.ERROR_MESSAGE);
            throw new Exception();    
       } 
       
      if(!expiredate()){
         JOptionPane.showMessageDialog(null, "Invalid Expire date !", "Message:", JOptionPane.ERROR_MESSAGE);
            throw new Exception();   
      }
      
      if(!cvvCode()){
         JOptionPane.showMessageDialog(null, "Invalid CVV code !", "Message:", JOptionPane.ERROR_MESSAGE);
            throw new Exception();    
      }
      
      if(!cardname()){
      JOptionPane.showMessageDialog(null, "Invalid Name on the card !", "Message:", JOptionPane.ERROR_MESSAGE);
            throw new Exception();        
      }
      
    }
      
    private boolean validatename() { //the user can only type the name useing lettters 

        return name2Text.getText().matches("([a-zA-Z]+|[a-zA-Z]+\\s[a-zA-Z]+)");
    }

    private boolean validatemobile() { //mobile number must start by 05 and continue with 8 number the total must be 10 numbers

        return phone2Text.getText().matches("(05)[0-9]{8}");
    }
    
    private boolean Adults(){ //the user can write how many number useing only numbers
        return adultText .getText().matches("[0-9]{1}");
    }
    
    private boolean children(){ //the user can write how many number useing only numbers
        return childrenText .getText().matches("[0-9]{1}");
    }
    
    private boolean cardNO(){ //must be 16 number without space or lettters 
        return cardnoText.getText().matches("[0-9]{16}");
    } 
    
    private boolean expiredate(){ //must be withen in this way 2 numbers then / the 2 numbers
        return expText.getText().matches("[0-9]{2}(/)[0-9]{2}");
    }
    
    private boolean cvvCode(){ // must be only 3 numbers 
        return cvvText.getText().matches("[0-9]{3}");
    }
    
    private boolean cardname(){ // can write on by useing letters first space then last 
        return nameoncardText.getText().matches("([a-zA-Z]+|[a-zA-Z]+\\s[a-zA-Z]+)");
    } 
    
    private void writeToFile(Object o) {
        // Creating stream objects.
        ObjectOutputStream objectOutputFile = null;
        FileOutputStream outStream = null;
        try {        
            outStream = new FileOutputStream("Reservation.txt");
            objectOutputFile = new ObjectOutputStream(outStream);
            // to Write serialized objects to file
            objectOutputFile.writeObject(o);
            objectOutputFile.close();
            
        } catch (FileNotFoundException ex) {
            System.out.println("Error wrting to file");
        } catch (IOException ex) {
            System.out.println("Error wrting to file");
        }
    }
}
    
         
    
        
            
           
    

     

