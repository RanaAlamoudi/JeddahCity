
package pp1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Rana_Alamoudi
 * Jana Falata
 */
public class PPP2Controller implements Initializable {

    @FXML
    private AnchorPane w2;
    @FXML
    private Label infoLabel;
    @FXML
    private Label name;
    @FXML
    private Label mobile;
    @FXML
    private Label DateOfBirth;
    @FXML
    private Label email;
    @FXML
    private Label gender;
    @FXML
    private Label password;
    @FXML
    private Button confirm;
    @FXML
    private Button reset;
    @FXML
    private TextField NAMETEXT;
    @FXML
    private TextField EMAILTEXT;
    @FXML
    private TextField PHONENO;
    @FXML
    private RadioButton female;
    @FXML
    private ToggleGroup genderRadio;
    @FXML
    private RadioButton male;
    @FXML
    private DatePicker DATE;
    @FXML
    private PasswordField PASS;
    @FXML
    private MenuBar menu;
    @FXML
    private MenuItem exit;
    @FXML
    private MenuItem background;
@FXML
    private ColorPicker backgroundColor;
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    // method that handles the event that is generated when the user selects confirm button
    private void confirmAction(ActionEvent event) throws Exception {
       inputValidation(); //calling the method  
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("PP3.fxml"));
            Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
        
        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        }
    }

    @FXML 
    // handles the event that is generated when the user selects reset button, reset all the information. 
    private void resetAction(ActionEvent event) {
        PASS.setText("");
        DATE.setValue(null);
        female.setSelected(false);
        male.setSelected(false);
        PHONENO.setText("");
        NAMETEXT.setText("");
        EMAILTEXT.setText("");   
    }
        
    @FXML // handles the event that is generated when the user selects Exit menuBar
    private void exitAction(ActionEvent event) {
        System.exit(0);
    }

    @FXML //this method gives the user the ability to change the background color 
    public void backgroundAction(ActionEvent event) {
        javafx.scene.paint.Color myColor = backgroundColor.getValue();
        w2.setBackground(new Background(new BackgroundFill(myColor , null ,null)));
    }
   
    //input validation will check that the user meet the condition if he didnt then a messege will appear 
    private void inputValidation() throws Exception {
        if (!validateName()) {
            JOptionPane.showMessageDialog(null, "Invalid Name !", "Message:", JOptionPane.ERROR_MESSAGE);
            throw new Exception();
        }

        if (!validateMobile()) { 
            JOptionPane.showMessageDialog(null, "Invalid Mobile number !", "Message:", JOptionPane.ERROR_MESSAGE);
            throw new Exception();
        }
  
        if (!validateEmail()) { 
            JOptionPane.showMessageDialog(null, "Invalid Email !", "Message:", JOptionPane.ERROR_MESSAGE);
            throw new Exception();
        }
               
        //if the user didnt choose the gender
        if (!male.isSelected() && !female.isSelected()) {
            JOptionPane.showMessageDialog(null, "Select the gender!", "Message:", JOptionPane.ERROR_MESSAGE);
            throw new Exception();
        }
        //if the user didnt choose the date
       if (DATE.getValue() == null || DATE.getValue().equals("")){
          JOptionPane.showMessageDialog(null, "Choose your Birth date !", "Message:", JOptionPane.ERROR_MESSAGE);
            throw new Exception(); 
         } 
       
         if (!validatePass()){
           JOptionPane.showMessageDialog(null, "Invalid Password !", "Message:", JOptionPane.ERROR_MESSAGE);
            throw new Exception();
       }

    }
    
    
    private boolean validateName() { //the reason from this method is that the user can only use litters to write the name

        return NAMETEXT.getText().matches("([a-zA-Z]+|[a-zA-Z]+\\s[a-zA-Z]+)");
    }
    
    private boolean validateEmail() { //the user must write the email in correct way and he must use @

        return EMAILTEXT.getText().matches("^(.+)@(.+)$");
    }

    private boolean validateMobile() { //mobile number must start by 05 and after that 8 number

        return PHONENO.getText().matches("(05)[0-9]{8}");
    }
    
    private boolean validatePass(){ // the password length must be 8 or more but not more than 20 and must not include spaces
       return PASS.getText().matches("^(?=.*[0-9])+|(?=.*[a-z])+|(?=.*[A-Z])+|(?=\\S+$).{8,20}$");
    } 
      
    
}
